<?php

    $titulo = array (

        '1' => 'Receita 1',
        '2' => 'Receita 2',
        '3' => 'Receita 3',
        '4' => 'Receita 4',
        '5' => 'Receita 5',
        '6' => 'Receita 6',
        '7' => 'Receita 7',
        '8' => 'Receita 8',
        '9' => 'Receita 9',
        '10' => 'Receita 10',
        '11' => 'Receita 11',
        '12' => 'Receita 12'
    );

    $foto = array(

        '1' => 'doce-001.jpg',
        '2' => 'doce-002.jpg',
        '3' => 'doce-003.jpg',
        '4' => 'bolo-001.jpg',
        '5' => 'bolo-002.jpg',
        '6' => 'bolo-003.jpg',
        '7' => 'suco-001.jpg',
        '8' => 'suco-002.jpg',
        '9' => 'suco-003.jpg',
        '10' => 'prato-quente-001.jpg',
        '11' => 'prato-quente-002.jpg',
        '12' => 'prato-quente-003.jpg'

    );

    $ingrediente = array (
    
        '1' => '',
    

    );

    $texto = array(


    );
?>




<?php
include_once('inc/classes.php');
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- JS / CSS -->
    <?php include_once('inc/css.php'); ?>
    <?php include_once('inc/js.php'); ?>
    <!-- / JS / CSS -->

    <title>Receitas</title>
</head>

<body>
    <div class="container">

        <!-- TOPO -->
        <?php include_once('inc/topo.php');?>
        <!-- /TOPO -->

        <div class="row mt-3"></div>

        <!-- MENU -->
        <?php include_once('inc/menu.php'); ?>
        <!--/ MENU -->

          <!-- BANNER -->
        <?php include_once('inc/banner.php'); ?>
        <!-- /BANNER -->

        <div class="row mt-5"></div>
        
        <!-- CONTEUDO -->
    
        <div class="row">
            <h1>Receita de doce</h1>
        </div>

        <div class="row">
            <div class="col-md-4">
                <img class="img-fluid receita_mini" src="img/doce-001.jpg" alt="Receita de Doce">
            </div>
            
            <div class="col-md-8">
            <h2>Ingredientes</h2>
       <ul>
         <li>12 Unidade de gema</li>
         <li>500 gr de acúcar</li>
         <li>2 colheres (sopa) de margarina</li>
         <li>200 ml de leite de côco</li>
         <li>200 gr de coco ralado</li>
        </ul>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <h2>Modo de Preparo</h2>
                <ol>
                    <li>Numa tigela, coloque o açúcar e a margarina;</li>
                    <li>Misture bem e em seguida adicione as gemas;</li>
                    <li>Continue misturando com a ajuda de um batedor de arame (fouet);</li>
                    <li>Acrescente o leite de coco e o coco ralado;</li>
                    <li>Misture tudo até que fique bem homogêneo;</li>
                    <li>Despeje essa mistura em forminhas untadas com margarina e salpicadas com açúcar;</li>
                    <li>DICA: unte bem para que os quindins fiquem mais brilhosos;</li>
                    <li>Leve para assar em forno baixo, pré aquecido, em banho maria por cerca de 30 minutos;</li>
                </ol>
            </div>
            <div class="col-md-6">
                <h2>Vídeo da Receita</h2>
                <iframe width="100%" height="315" src="https://www.youtube.com/embed/xYyhO5xzx7g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
        </div>
        <!-- /CONTEUDO -->
        
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php');?>
        <!-- /RODAPE -->
    </div>
</body>

</html>