<?php
include_once('inc/classes.php');
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- JS / CSS -->
    <?php include_once('inc/css.php'); ?>
    <?php include_once('inc/js.php'); ?>
    <!-- / JS / CSS -->

    <title>Receitas</title>
</head>

<body>
    <div class="container">

    <!-- TOPO -->
   <?php include_once('inc/topo.php');?>
    <!-- /TOPO -->

    <div class="row mt-3"></div>

        <!-- MENU -->
        <?php include_once('inc/menu.php'); ?>
        <!-- /MENU -->

        <!-- BANNER -->
        <?php include_once('inc/banner.php'); ?>
        <!-- /BANNER -->

        <!-- CONTEUDO -->

        <div class="row mt-5"></div>

        <!-- ############## O QUE FAZEMOS ############# -->
        <div class="row text-center mt-4 md-4">
            <h2>O que fazemos</h2>
            <h3>Venha provar nossas delícias</h3>
        </div>

        <div class="row mt-5"></div>
        <div class="row mt-2"></div>

        <div class="row text-center oquefazemos">
                <div class="col-sm-3 col-xs-6">
                    <img src="img/icone-doces.png" alt="Doces" class="img-fluid">
                    <h4>Doces</h4>
                    <p>Doces Tradicionais e receitas secretas</p>
                </div>

                <div class="col-sm-3 col-xs-6">
                    <img src="img/icone-bolos.png" alt="Bolos" class="img-fluid">
                    <h4>Bolos</h4>
                    <p>Caseiros ou profissionais, sempre uma delícia</p>
                </div>

                <div class="col-sm-3 col-xs-6">
                    <img src="img/icone-sucos.png" alt="Sucos" class="img-fluid">
                    <h4>Sucos</h4>
                    <p>Naturais com as mais diversas frutas.</p>
                </div>

                <div class="col-sm-3 col-xs-6">
                    <img src="img/icone-pratos-quentes.png" alt="Pratos Quentes" class="img-fluid">
                    <h4>Pratos Quentes</h4>
                    <p>Nossas receitas vão te surpreender</p>
                </div>
        </div>
        <!-- ############## /O QUE FAZEMOS ############# -->

        <div class="row mt-5"></div>

        <!-- ################# DICAS ################ -->
        <div class="row text-center mt-4">
                <h2>Dicas de Receitas</h2>
            </div>
        <div class="row dicas mt-3">

            <div class="col-sm-4 card" style="padding: 3%;">
                <img src="img/prato-001.png" alt="Dica de Prato" class="card card-img-top">
                <h2>Prato 1</h2>
                <p>Mussum Ipsum, cacilds vidis litro abertis. Interagi no mé, cursus quis, vehicula ac nisi.Tá deprimidis, eu conheço uma cachacis 
                que pode alegrar sua vidis.Si num tem leite então bota uma pinga aí cumpadi!Mais vale um bebadis conhecidiss, que um alcoolatra anonimis.</p>
            </div>

            <div class="col-sm-4 card" style="padding: 3%;">
                <img src="img/prato-005.png" alt="Dica de Prato" class="card card-img-top">
                <h2>Prato 2</h2>
                <p>Mussum Ipsum, cacilds vidis litro abertis. Interagi no mé, cursus quis, vehicula ac nisi.Tá deprimidis, eu conheço uma cachacis 
                que pode alegrar sua vidis.Si num tem leite então bota uma pinga aí cumpadi!Mais vale um bebadis conhecidiss, que um alcoolatra anonimis.</p>
            </div>

            <div class="col-sm-4 card" style="padding: 3%;">
                <img src="img/prato-006.png" alt="Dica de Prato" class="card card-img-top">
                <h2>Prato 3</h2>
                <p>Mussum Ipsum, cacilds vidis litro abertis. Interagi no mé, cursus quis, vehicula ac nisi.Tá deprimidis, eu conheço uma cachacis 
                que pode alegrar sua vidis.Si num tem leite então bota uma pinga aí cumpadi!Mais vale um bebadis conhecidiss, que um alcoolatra anonimis.</p>
            </div>

            <div class="col-sm-4 d-none d-sm-block card" style="padding: 3%;">
                <img src="img/prato-002.png" alt="Dica de Prato" class="card card-img-top">
                <h2>Prato 4</h2>
                <p>Mussum Ipsum, cacilds vidis litro abertis. Interagi no mé, cursus quis, vehicula ac nisi.Tá deprimidis, eu conheço uma cachacis 
                que pode alegrar sua vidis.Si num tem leite então bota uma pinga aí cumpadi!Mais vale um bebadis conhecidiss, que um alcoolatra anonimis.</p>
            </div>

            <div class="col-sm-4 d-none d-sm-block card" style="padding: 3%;">
                <img src="img/prato-003.png" alt="Dica de Prato" class="card card-img-top">
                <h2>Prato 5</h2>
                <p>Mussum Ipsum, cacilds vidis litro abertis. Interagi no mé, cursus quis, vehicula ac nisi.Tá deprimidis, eu conheço uma cachacis 
                que pode alegrar sua vidis.Si num tem leite então bota uma pinga aí cumpadi!Mais vale um bebadis conhecidiss, que um alcoolatra anonimis.</p>
            </div>

            <div class="col-sm-4 d-none d-sm-block card" style="padding: 3%;">
                <img src="img/prato-004.png" alt="Dica de Prato" class="card card-img-top">
                <h2>Prato 6</h2>
                <p>Mussum Ipsum, cacilds vidis litro abertis. Interagi no mé, cursus quis, vehicula ac nisi.Tá deprimidis, eu conheço uma cachacis 
                que pode alegrar sua vidis.Si num tem leite então bota uma pinga aí cumpadi!Mais vale um bebadis conhecidiss, que um alcoolatra anonimis.</p>
            </div>
        </div>
        <!-- ################# /DICAS ################ -->

        <div class="row mt-5"></div>

        <!-- /CONTEUDO -->

        <!-- RODAPE -->
        <?php include_once('inc/rodape.php');?>
        <!-- /RODAPE -->

    </div>
</body>

</html>