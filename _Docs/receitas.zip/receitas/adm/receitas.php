<?php

    include_once('inc/classes.php')

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área administrativa</title>

    <!-- CSS / JS -->
    <?PHP 
    include_once('inc/css.php');
    include_once('inc/js.php');?>
    <!-- / CSS / JS -->
</head>
<body>
    
    <div class="container">
    <!-- Menu -->
        <div class="row">
           <?php include_once('inc/menu-adm.php'); ?>
        </div>
    <!-- /Menu -->


    <!-- Principal -->
        <div class="row">
            <h1>Receitas</h1>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th class="col-md-1">Ações </th>
                            <th class="col-md-1">Categoria</th>
                            <th class="col-md-1">Data</th>
                            <th class="col-md-1">Título</th>
                        </tr>
                        <tbody>
                            <?php
                            $objCategoria = new Categoria();
                            $categorias = $objCategoria -> listar();
                            foreach($categorias as $categoria){
                            ?>
                            <tr>
                                <td class="col-md-1">
                                    <a class="btn btn-primary mr-1" href="receitas-editar.php?id=<?php echo $categoria -> id_categoria;?>"><i class="bi bi-pencil"></i></a>
                                    <a class="btn btn-dark" href="categoria-excluir.php?id=<?php echo $categoria -> id_categoria;?>"><i class="bi bi-trash3"></i></a>
                                    <a class="btn btn-success" href="receita.php?id=<?php echo $categoria -> id_categoria;?>"><i class="bi bi-eye-fill"></i></a>
                                </td>
                                    <td class="col-md-1"><?php echo $categoria -> categoria;?></td>
                                    <td class="col-md-1"></td>
                                    <td class="col-md-1" ></td>
                            </tr>       
                            <?php 
                                }
                            ?>
                        </tbody>
                    </thead>


                </table>
        </div>
    <!-- /Principal -->


    <!-- Rodape -->
        <div class="row">
            Rodapé  
        </div>
    <!-- /Rodape -->

    </div>

</body>
</html>