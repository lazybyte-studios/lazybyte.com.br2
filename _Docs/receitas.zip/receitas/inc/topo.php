<div class="row">
    <!-- TOPO -->
        <div id="logo" class="col-sm-6 col-2"><img src="img/logo-receitas.png" alt=""></div>

        <div id="contato" class="col-sm-4  col-6 text-center pt-3">
            <p>Contato: (11) 92345-6788</p>
            <p>contato@receitas.com.br</p>
        </div>

        <div id="redes" class="col-sm-2 col-4 text-center pt-3">
            <i class="fa-brands fa-facebook-f"></i>
            <i class="fa-brands fa-instagram"></i>
            <i class="fa-brands fa-youtube"></i>
            <i class="fa-brands fa-twitter"></i>
        </div>
    <!-- /TOPO -->
    </div>
