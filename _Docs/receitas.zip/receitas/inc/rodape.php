<div class="row rodape mt-5 border-top border-5 text-center patrocinio">
<div class="col-md-4 pt-md-4">Todos os direitos reservados</div>
<!-- ###### /PATROCINIO ###### -->
    <div class="col-md-4 ">       
            <div id="carouselExampleSlidesOnly" class="carousel slide carousel-fade" data-ride="carousel">
                <div class="carousel-inner text-center">
                    <div class="carousel-item active">
                        <img class="img-fluid" src="img/patrocinio-ifood.png" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="img-fluid" src="img/patrocinio-rappi.png" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="img-fluid" src="img/patrocinio-seu-menu.png" alt="Third slide">
                    </div>
                    <div class="carousel-item">
                        <img class="img-fluid" src="img/patrocinio-uber-eats.png" alt="Third slide">
                    </div>
                 </div>
            </div>
         </div>
<!-- ###### /PATROCINIO ###### -->
    <div class="col-md-4 pt-md-4">Site desenvolvido por Gabriel Morganti</div>
    </div>
</div>