<div class="row d-none d-sm-block">
            <?php Banner::mostrar();?>
        </div>