<?php

include_once('./class/Banner.php');
include_once('./class/Conexao.php');
include_once('./class/Categoria.php');
include_once('./class/Helper.php');


?>
