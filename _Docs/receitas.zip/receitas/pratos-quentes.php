<?php
include_once('inc/classes.php');
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- JS / CSS -->
    <?php include_once('inc/css.php'); ?>
    <?php include_once('inc/js.php'); ?>
    <!-- / JS / CSS -->

    <title>Receitas</title>
</head>

<body>
    <div class="container">

        <!-- TOPO -->
         <?php include_once('inc/topo.php');?>
         <!-- /TOPO -->

         <div class="row mt-3"></div>
        
        <!-- MENU -->
        <?php include_once('inc/menu.php'); ?>
        <!--/ MENU -->

         <!-- BANNER -->
         <?php include_once('inc/banner.php'); ?>
        <!-- /BANNER -->

        <!-- CONTEUDO -->
        <div class="row text-center">
        <H1><i class="fa-solid fa-plate-wheat"></i> PRATOS QUENTES</H1>
        </div>

        <div class="row mt-2 border-top border-1 p-2">
            <div class="col-sm-2 col-3"> <img class="foto_mini" src="img/prato-quente-001.jpg" alt="Foto Receita"> </div>
            <div class="col-sm-8 col-6 p-2">Arroz Soltinho</div>
            <div class="col-sm-2 col-3 p-2"> <a href="descricao-da-receita.php" target="_self">Ver</a></div>
        </div>  

        <div class="row mt-2 border-top border-1 p-2">
            <div class="col-sm-2 col-3"> <img class="foto_mini" src="img/prato-quente-002.jpg" alt="Foto Receita"> </div>
            <div class="col-sm-8 col-6 p-2">Macarrão Alho e Óleo</div>
            <div class="col-sm-2 col-3 p-2"> <a href="descricao-da-receita.php" target="_self">Ver</a></div>
        </div>  

        <div class="row mt-2 border-top border-1 p-2">
            <div class="col-sm-2 col-3"> <img class="foto_mini" src="img/prato-quente-003.jpg" alt="Foto Receita"> </div>
            <div class="col-sm-8 col-6 p-2">Burrito de Frango</div>
            <div class="col-sm-2 col-3 p-2"> <a href="descricao-da-receita.php" target="_self">Ver</a></div>
        </div> 
        <!-- /CONTEUDO -->
        
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php');?>
        <!-- /RODAPE -->
    </div>
</body>

</html>